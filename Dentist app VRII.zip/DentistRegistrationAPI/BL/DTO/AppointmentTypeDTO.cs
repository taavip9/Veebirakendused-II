﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class AppointmentTypeDTO
    {
        public int AppointmentTypeId;

        public String Name;

        public static AppointmentTypeDTO CreateFromDomain(AppointmentType appointmentType)
        {
            if (appointmentType == null) return null;
            return new AppointmentTypeDTO()
            {
                AppointmentTypeId = appointmentType.Id,
                Name = appointmentType.Name
            };
        }
    }
}

