﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class ProcedureDTO
    {
        public int ProcedureId { set; get; }
        public String Name { set; get; }
        public String Description { set; get; }
        public List<PersonClinicDTO> PersonClinics { set; get; }

        public static ProcedureDTO CreateFromDomain(Procedure pr)
        {
            if (pr == null) return null;
            return new ProcedureDTO()
            {
                ProcedureId = pr.Id,
                Name = pr.Name,
                Description = pr.Description,
                PersonClinics = pr.PersonClinics.Select(pc => PersonClinicDTO.CreateFromDomain(pc)).ToList()
            };

        }
    }
}
