﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class PersonDTO
    {
        public int PersonId { get; set; }
        public string IdentityCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public List<PersonContactDTO> PersonContact { get; set; }
        public List<PersonClinicDTO> PersonClinic { get; set; }
        public List<AppointmentDTO> PersonAppointments { get; set; }
        public List<PersonRoleDTO> PersonRoles { get; set; }

        public static PersonDTO CreateFromDomain(Person person)
        {
            if (person == null) return null;

            return new PersonDTO()
            {
                PersonId = person.Id,
                IdentityCode = person.IdentityCode,
                FirstName = person.Firstname,
                LastName = person.Lastname,
                PersonAppointments = person.Appointments?.Select(a => AppointmentDTO.CreateFromDomain(a)).ToList(),
                PersonRoles = person.PersonRoles?.Select(pr => PersonRoleDTO.CreateFromDomain(pr)).ToList(),
                PersonClinic = person.PersonClinics?.Select(pc => PersonClinicDTO.CreateFromDomain(pc)).ToList(),
                PersonContact = person.PersonContacts?.Select(pc => PersonContactDTO.CreateFromDomain(pc)).ToList()
            };
        }
    }
}
