﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class RoleDTO
    {
        public int RoleId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public List<PersonRoleDTO> PersonRoles { get; set; }

        public static RoleDTO CreateFromDomain(Role ro)
        {
            if (ro == null) return null;
            return new RoleDTO()
            {
                RoleId = ro.Id,
                Name = ro.Name,
                Description = ro.Description,
                PersonRoles = ro.PersonRoles.Select(pr => PersonRoleDTO.CreateFromDomain(pr)).ToList()
            };

        }
    }
}
