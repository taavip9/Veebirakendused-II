﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class PersonRoleDTO
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public PersonDTO Person { get; set; }
        public RoleDTO Role { get; set; }
        public static PersonRoleDTO CreateFromDomain(PersonRole pr)
        {
            return new PersonRoleDTO()
            {
                StartDate = pr.StartDate,
                EndDate = pr.EndDate,
                Person = PersonDTO.CreateFromDomain(pr.Person),
                Role = RoleDTO.CreateFromDomain(pr.Role),
            };
        }
    }
}
