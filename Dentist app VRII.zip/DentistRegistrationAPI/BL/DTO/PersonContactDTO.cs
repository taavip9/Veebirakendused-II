﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class PersonContactDTO
    {
        public int PersonContactId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        //public PersonDTO Person { get; set; }
        //public ContactDTO Contact { get; set; }

        public static PersonContactDTO CreateFromDomain(PersonContact pc)
        {
            if (pc == null) return null;

            return new PersonContactDTO()
            {
                PersonContactId = pc.Id,
                StartDate = pc.StartDate,
                EndDate = pc.EndDate,
                //Person = PersonDTO.CreateFromDomain(pc.Person),
                //Contact = ContactDTO.CreateFromDomain(pc.Contact)
            };
        }
    }
}
