﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class ClinicDTO
    {

        public int ClinicId { get; set; }
        public string Address { get; set; }
        public string ContactPhone { get; set; }
        public string ContactMail { get; set; }
        public string Description { get; set; }
        public List<PersonClinicDTO> PersonClinics { get; set; }
        public List<WorkingHoursDTO> WorkingHours { get; set; }

        public static ClinicDTO CreateFromDomain(Clinic cl)
        {
            if (cl == null) return null;

            return new ClinicDTO()
            {
                ClinicId = cl.Id,
                Address = cl.Address,
                ContactMail = cl.ContactMail,
                ContactPhone = cl.ContactPhone,
                Description = cl.Description,
                PersonClinics = cl.PersonClinics?.Select(pc => PersonClinicDTO.CreateFromDomain(pc)).ToList(),
                WorkingHours = cl.WorkingHours?.Select(wh => WorkingHoursDTO.CreateFromDomain(wh)).ToList()
            };
        }
    }
}
