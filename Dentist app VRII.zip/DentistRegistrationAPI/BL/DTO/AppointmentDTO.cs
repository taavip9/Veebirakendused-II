﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain;


namespace BL.DTO
{
     public class AppointmentDTO
    {
        public int AppoinmentId { get; set; }
        public DateTime AppDate { get; set; }
        public TimeSpan Length { get; set; }
        public AppointmentTypeDTO AppointmentType { get; set; }
        public PersonDTO PatientPerson { get; set; }
        public PersonDTO DoctorPerson { get; set; }
        public PersonClinicDTO PersonClinic { get; set; }

        public static AppointmentDTO CreateFromDomain(Appointment ap)
        {
            return new AppointmentDTO()
            {
                AppoinmentId = ap.Id,
                AppDate = ap.AppDate,
                Length = ap.Length,
                AppointmentType = AppointmentTypeDTO.CreateFromDomain(ap.AppointmentType),
                DoctorPerson = PersonDTO.CreateFromDomain(ap.Person),
                PatientPerson = PersonDTO.CreateFromDomain(ap.Person)
            };
        }
    }
}
