﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class PersonClinicDTO
    {
        public int PersonClinicId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public ProcedureDTO Procedure { get; set; }
        public PersonDTO Person { get; set; }
        public ClinicDTO Clinic { get; set; }
        public List<AppointmentDTO> Appointments { get; set; }

        public static PersonClinicDTO CreateFromDomain(PersonClinic pc)
        {
            if (pc == null) return null;
            return new PersonClinicDTO()
            {
                StartDate = pc.StartDate,
                EndDate = pc.EndDate,
                Procedure = ProcedureDTO.CreateFromDomain(pc.Procedure),
                Person = PersonDTO.CreateFromDomain(pc.Person),
                Clinic = ClinicDTO.CreateFromDomain(pc.Clinic),
                Appointments = pc.Appointments?.Select(ap => AppointmentDTO.CreateFromDomain(ap)).ToList()

            };
        }
    }
}
