﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class ContactDTO
    {
        public int ContactId { get; set; }
        public string Phone { get; set; }
        public string Mail { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string HouseNumber { get; set; }
        public string ApartmentNumber { get; set; }
        public List<PersonContactDTO> PersonContacts { get; set; }

        public static ContactDTO CreateFromDomain(Contact co)
        {
            if (co == null) return null;
            return new ContactDTO()
            {
                ContactId = co.Id,
                Phone = co.Phone,
                Mail = co.Mail,
                City = co.City,
                Street = co.Street,
                HouseNumber = co.HouseNumber,
                ApartmentNumber = co.ApartmentNumber,
                //PersonContacts = co.PersonContacts?.Select(pc => PersonContactDTO.CreateFromDomain(pc)).ToList()
            };
        }
    }
}
