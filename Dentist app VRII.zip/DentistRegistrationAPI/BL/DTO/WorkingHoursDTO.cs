﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain;

namespace BL.DTO
{
    public class WorkingHoursDTO
    {
        public int WorkingHourId { get; set; }
        public DateTime OpenFrom { get; set; }
        public DateTime OpenTo { get; set; }
        public string Weekday { get; set; }
        public ClinicDTO Clinic { get; set; }

        public static WorkingHoursDTO CreateFromDomain(WorkingHours wh)
        {
            if (wh == null) return null;
            return new WorkingHoursDTO()
            {
                WorkingHourId = wh.Id,
                OpenFrom = wh.OpenFrom,
                OpenTo = wh.OpenTo,
                Weekday = wh.Weekday,
                Clinic = ClinicDTO.CreateFromDomain(wh.Clinic)
            };
        }
    }
}
