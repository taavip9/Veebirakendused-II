﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;

namespace BL
{
    public interface IPersonService
    {
        List<PersonDTO> GetAllPersons();

        PersonDTO GetPersonById(int personId);

        PersonDTO AddNewPerson(PersonDTO newPerson);

        List<PersonDTO> GetPersonWithContactsById(int personId);

        void UpdatePerson(int personId, PersonDTO personNewData);
    }
}
