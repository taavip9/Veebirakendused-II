﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IPersonRoleService
    {
        List<PersonRoleDTO> GetAllPersonRoles();

        PersonRoleDTO GetPersonRoleById(int apersonRoleId);

        PersonRoleDTO AddNewPersonRole(PersonRoleDTO newPersonRole);

        void UpdatePersonRole(int personRoleId, PersonRoleDTO personRoleNewData);

    }
}