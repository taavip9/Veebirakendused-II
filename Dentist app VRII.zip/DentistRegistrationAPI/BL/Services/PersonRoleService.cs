﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;

namespace BL.Services
{
    class PersonRoleService : IPersonRoleService
    {
        public List<PersonRoleDTO> GetAllPersonRoles()
        {
            throw new NotImplementedException();
        }

        public PersonRoleDTO GetPersonRoleById(int apersonRoleId)
        {
            throw new NotImplementedException();
        }

        public PersonRoleDTO AddNewPersonRole(PersonRoleDTO newPersonRole)
        {
            throw new NotImplementedException();
        }

        public void UpdatePersonRole(int personRoleId, PersonRoleDTO personRoleNewData)
        {
            throw new NotImplementedException();
        }
    }
}
