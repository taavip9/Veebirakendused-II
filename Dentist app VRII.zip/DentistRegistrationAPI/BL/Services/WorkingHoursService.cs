﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;

namespace BL.Services
{
    class WorkingHoursService : IWorkingHoursService
    {
        public List<WorkingHoursDTO> GetAllWorkingHours()
        {
            throw new NotImplementedException();
        }

        public WorkingHoursDTO GetWorkingHoursById(int workingHoursId)
        {
            throw new NotImplementedException();
        }

        public WorkingHoursDTO AddNewWorkingHours(WorkingHoursDTO newWorkingHours)
        {
            throw new NotImplementedException();
        }

        public void UpdateWorkingHours(int workingHoursId, WorkingHoursDTO workingHoursNewData)
        {
            throw new NotImplementedException();
        }
    }
}
