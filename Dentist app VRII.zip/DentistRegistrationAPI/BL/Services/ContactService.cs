﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;

namespace BL.Services
{
    public class ContactService : IContactService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IContactFactory _contactFactory;
        public ContactService(DAL.App.Interfaces.IAppUnitOfWork uow, IContactFactory contactFactory)
        {
            _uow = uow;
            _contactFactory = contactFactory;
        }
        public List<ContactDTO> GetAllContacts()
        {
            return _uow.Contacts.All().Select(p => _contactFactory.Transform(p)).ToList();
        }

        public ContactDTO GetContactById(int contactId)
        {
            return _contactFactory.Transform(_uow.Contacts.Find(contactId));
        }

        public ContactDTO FindContactByPersonId(int personId)
        {
            return _contactFactory.Transform(_uow.Contacts.findContactByPersonId(personId));
        }

        public ContactDTO AddNewContact(ContactDTO newContact)
        {
            var contact = _contactFactory.Transform(newContact);
            _uow.Contacts.Add(contact);
            _uow.SaveChanges();
            return newContact;
        }

        public void UpdateContact(int contactId, ContactDTO contactNewData)
        {
            var contact = new ContactDTO();
            //person.LastName = personNewData.LastName;
            var updatedContact = _contactFactory.Transform(contact);
            _uow.Contacts.Update(updatedContact);
            _uow.SaveChanges();
        }
    }
}
