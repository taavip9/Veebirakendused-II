﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;

namespace BL.Services
{
    public class ClinicService : IClinicService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IClinicFactory _clinicFactory;
        public ClinicService(DAL.App.Interfaces.IAppUnitOfWork uow, IClinicFactory clinicFactory)
        {
            _uow = uow;
            _clinicFactory = clinicFactory;
        }
        public List<ClinicDTO> GetAllClinics()
        {
            return _uow.Clinics.All().Select(p => _clinicFactory.Transform(p)).ToList();
        }

        public ClinicDTO GetClinicById(int clinicId)
        {
            return _clinicFactory.Transform(_uow.Clinics.Find(clinicId));
        }

        public ClinicDTO AddNewClinic(ClinicDTO newClinic)
        {
            var clinic = _clinicFactory.Transform(newClinic);
            _uow.Clinics.Add(clinic);
            _uow.SaveChanges();
            return newClinic;
        }

        public void UpdateClinic(int clinicId, ClinicDTO clinicNewData)
        {
            var clinic = new ClinicDTO();
            clinic.ClinicId = clinicId;
            clinic.Description = clinicNewData.Description;
            var updatedClinic = _clinicFactory.Transform(clinic);
            _uow.Clinics.Update(updatedClinic);
            _uow.SaveChanges();
        }
    }
}
