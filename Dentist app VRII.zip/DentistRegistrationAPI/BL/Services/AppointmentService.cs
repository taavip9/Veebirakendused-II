﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;

namespace BL.Services
{
    public class AppointmentService : IAppointmentService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IAppointmentFactory _appointmentFactory;
        public AppointmentService(DAL.App.Interfaces.IAppUnitOfWork uow, IAppointmentFactory appointmentFactory)
        {
            _uow = uow;
            _appointmentFactory = appointmentFactory;
        }
        public List<AppointmentDTO> GetAllAppointments()
        {
            return _uow.Appointments.All().Select(p => _appointmentFactory.Transform(p)).ToList();
        }

        public AppointmentDTO GetAppointmentById(int appointmentId)
        {
            return _appointmentFactory.Transform(_uow.Appointments.Find(appointmentId));
        }

        public List<AppointmentDTO> GetAppointmentByCustomerId(int customerPersonId)
        {
            return _uow.Appointments.FindAppointmentsByPatientId(customerPersonId).Select(p => _appointmentFactory.Transform(p)).ToList();
        }

        public AppointmentDTO AddNewAppointment(AppointmentDTO newAppointment)
        {
            var appointment = _appointmentFactory.Transform(newAppointment);
            _uow.Appointments.Add(appointment);
            _uow.SaveChanges();
            return newAppointment;
        }

        public void UpdateAppointment(int personId, AppointmentDTO appointmentNewData)
        {
            var appointment = new AppointmentDTO();
            appointment.AppointmentType = appointmentNewData.AppointmentType;
            var updatedAppointment = _appointmentFactory.Transform(appointment);
            _uow.Appointments.Update(updatedAppointment);
            _uow.SaveChanges();
        }
    }
}
