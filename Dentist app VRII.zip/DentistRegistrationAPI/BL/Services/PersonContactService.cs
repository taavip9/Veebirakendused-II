﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;
using DAL.App.Interfaces;
using Domain;

namespace BL.Services
{
    public class PersonContactService : IPersonContactService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IPersonContactFactory _personContactFactory;

        public PersonContactService(DAL.App.Interfaces.IAppUnitOfWork uow, IPersonContactFactory personContactFactory)
        {
            _uow = uow;
            _personContactFactory = personContactFactory;
        }

        public List<PersonContactDTO> GetAllPersonContacts()
        {
            throw new NotImplementedException();
        }

        public List<PersonContactDTO> GetByPersonId(int PersonId)
        {
            List<PersonContactDTO> matchingPersonContacts;
            matchingPersonContacts = _uow.PersonContacts.All().FindAll(
                delegate(PersonContact pc)
                {
                    return pc.PersonId == PersonId;
                }).Select(p => _personContactFactory.Transform(p)).ToList();

            return matchingPersonContacts;
        }

        public PersonContactDTO AddNewPersonContact(PersonContactDTO newPersonContact)
        {
            throw new NotImplementedException();
        }

        public void UpdatePersonContact(int personContactId, PersonContactDTO personContactNewData)
        {
            throw new NotImplementedException();
        }
    }
}
