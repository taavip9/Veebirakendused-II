﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;
using DAL.App.Interfaces;
using Domain;

namespace BL.Services
{
    public class PersonService : IPersonService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IPersonFactory _personFactory;
        public PersonService(DAL.App.Interfaces.IAppUnitOfWork uow, IPersonFactory personFactory)
        {
            _uow = uow;
            _personFactory = personFactory;
        }
        public List<PersonDTO> GetAllPersons()
        {
            return _uow.Persons.All().Select(p => _personFactory.Transform(p)).ToList();
        }
        public PersonDTO GetPersonById(int personId)
        {
            return _personFactory.Transform(_uow.Persons.Find(personId));
        }
        public List<PersonDTO> GetPersonWithContactsById(int personId)
        {
            return _uow.Persons.findWithMatchingContacts(personId).Select(p => _personFactory.Transform(p)).ToList();
        }

        public PersonDTO AddNewPerson(PersonDTO newPerson)
        {
            var person = _personFactory.Transform(newPerson);
            _uow.Persons.Add(person);
            _uow.SaveChanges();
            return newPerson;
        }

        public void UpdatePerson(int personId, PersonDTO personNewData)
        {
            var person = new PersonDTO();
            person.PersonId = personId;
            person.FirstName = personNewData.FirstName;
            person.LastName = personNewData.LastName;
            var updatedPerson = _personFactory.Transform(person);
            _uow.Persons.Update(updatedPerson);
            _uow.SaveChanges();
        }
    }
}
