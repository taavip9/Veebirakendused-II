﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;

namespace BL.Services
{
    class ProcedureService : IProcedureService
    {
        public List<ProcedureDTO> GetAllProcedures()
        {
            throw new NotImplementedException();
        }

        public ProcedureDTO GetProcedureById(int procedureId)
        {
            throw new NotImplementedException();
        }

        public ProcedureDTO AddNewProcedure(ProcedureDTO newProcedure)
        {
            throw new NotImplementedException();
        }

        public void UpdateProcedure(int personId, ProcedureDTO procedureNewData)
        {
            throw new NotImplementedException();
        }
    }
}
