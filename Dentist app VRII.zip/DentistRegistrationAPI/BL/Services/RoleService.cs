﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;

namespace BL.Services
{
    class RoleService : IRoleService
    {
        public List<RoleDTO> GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public RoleDTO GetRoleById(int roleId)
        {
            throw new NotImplementedException();
        }

        public RoleDTO AddNewRole(RoleDTO newRole)
        {
            throw new NotImplementedException();
        }

        public void UpdateRole(int roleId, RoleDTO roleNewData)
        {
            throw new NotImplementedException();
        }
    }
}
