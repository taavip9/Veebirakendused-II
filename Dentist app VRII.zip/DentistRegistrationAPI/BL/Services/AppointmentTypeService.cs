﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;

namespace BL.Services
{
    class AppointmentTypeService : IAppointmentTypeService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IAppointmentTypeFactory _appointmentTypeFactory;

        public AppointmentTypeService(DAL.App.Interfaces.IAppUnitOfWork uow, IAppointmentTypeFactory appointmentTypeFactory)
        {
            _uow = uow;
            _appointmentTypeFactory = appointmentTypeFactory;
        }

        public List<AppointmentTypeDTO> GetAllAppointmentTypes()
        {
            return _uow.AppointmentTypes.All().Select(p => _appointmentTypeFactory.Transform(p)).ToList();
        }

        public AppointmentTypeDTO GetAppointmentTypeById(int appointmentTypeId)
        {
            return _appointmentTypeFactory.Transform(_uow.AppointmentTypes.Find(appointmentTypeId));
        }

        public AppointmentTypeDTO AddNewAppointmentType(AppointmentTypeDTO newAppointmentType)
        {
            var appointmentType = _appointmentTypeFactory.Transform(newAppointmentType);
            _uow.AppointmentTypes.Add(appointmentType);
            _uow.SaveChanges();
            return newAppointmentType;
        }

        public void UpdateAppointmentType(int appointmentTypeId, AppointmentTypeDTO appointmentTypeNewData)
        {
            var appointmentType = new AppointmentTypeDTO {Name = appointmentTypeNewData.Name};
            var updatedAppointmentType = _appointmentTypeFactory.Transform(appointmentType);
            _uow.AppointmentTypes.Update(updatedAppointmentType);
            _uow.SaveChanges();
        }
    }
}
