﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using BL.Factories;

namespace BL.Services
{
    class PersonClinicService : IPersonClinicService
    {
        private readonly DAL.App.Interfaces.IAppUnitOfWork _uow;
        private readonly IPersonClinicFactory _personClinicFactory;

        public PersonClinicService(DAL.App.Interfaces.IAppUnitOfWork uow, IPersonClinicFactory personClinicFactory)
        {
            _uow = uow;
            _personClinicFactory = personClinicFactory;
        }
        public List<PersonClinicDTO> GetAllPersonClinics()
        {
            return _uow.PersonClinics.All().Select(p => _personClinicFactory.Transform(p)).ToList();
        }

        public PersonClinicDTO GetPersonClinicById(int personClinicId)
        {
            return _personClinicFactory.Transform(_uow.PersonClinics.Find(personClinicId));
        }

        public PersonClinicDTO AddNewPersonClinic(PersonClinicDTO newPersonClinic)
        {
            var personClinic = _personClinicFactory.Transform(newPersonClinic);
            _uow.PersonClinics.Add(personClinic);
            _uow.SaveChanges();
            return newPersonClinic;
        }

        public void UpdatePersonClinic(int personClinicId, PersonClinicDTO personClinicNewData)
        {
            throw new NotImplementedException();
        }
    }
}
