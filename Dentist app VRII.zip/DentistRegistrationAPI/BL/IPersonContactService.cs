﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IPersonContactService
    {
        List<PersonContactDTO> GetAllPersonContacts();

        List<PersonContactDTO> GetByPersonId(int PersonId);

        PersonContactDTO AddNewPersonContact(PersonContactDTO newPersonContact);

        void UpdatePersonContact(int personContactId, PersonContactDTO personContactNewData);
    }
}