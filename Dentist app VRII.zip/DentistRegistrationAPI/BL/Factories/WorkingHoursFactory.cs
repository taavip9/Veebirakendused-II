﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IWorkingHoursFactory
    {
        WorkingHoursDTO Transform(WorkingHours a);
        WorkingHours Transform(WorkingHoursDTO dto);
    }

    public class WorkingHoursFactory : IWorkingHoursFactory
    {
        public WorkingHoursDTO Transform(WorkingHours wh)
        {
            return new WorkingHoursDTO()
            {
                WorkingHourId = wh.Id,
                OpenFrom = wh.OpenFrom,
                OpenTo = wh.OpenTo,
                Weekday = wh.Weekday,
                Clinic = ClinicDTO.CreateFromDomain(wh.Clinic)
            };
        }

        public WorkingHours Transform(WorkingHoursDTO dto)
        {
            return new WorkingHours()
            {
                Id = dto.WorkingHourId,
                OpenFrom = dto.OpenFrom,
                OpenTo = dto.OpenTo,
                Weekday = dto.Weekday,
                ClinicId = dto.Clinic.ClinicId
            };

        }
    }
}
