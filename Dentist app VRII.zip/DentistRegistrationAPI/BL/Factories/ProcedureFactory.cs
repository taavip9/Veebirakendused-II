﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IProcedureFactory
    {
        ProcedureDTO Transform(Procedure a);
        Procedure Transform(ProcedureDTO dto);
    }

    public class ProcedureFactory : IProcedureFactory
    {
        public ProcedureDTO Transform(Procedure pr)
        {
            return new ProcedureDTO()
            {
                ProcedureId = pr.Id,
                Name = pr.Name,
                Description = pr.Description,
                PersonClinics = pr.PersonClinics.Select(pc => PersonClinicDTO.CreateFromDomain(pc)).ToList()
            };
        }

        public Procedure Transform(ProcedureDTO dto)
        {
            return new Procedure()
            {
                Id = dto.ProcedureId,
                Name = dto.Name,
                Description = dto.Description,
            };
        }
    }
}
