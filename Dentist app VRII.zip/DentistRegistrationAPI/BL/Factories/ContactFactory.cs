﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{

    public interface IContactFactory
    {
        ContactDTO Transform(Contact c);
        Contact Transform(ContactDTO dto);
    }

    public class ContactFactory : IContactFactory
    {
        public ContactDTO Transform(Contact co)
        {
            return new ContactDTO()
            {
                ContactId = co.Id,
                Phone = co.Phone,
                Mail = co.Mail,
                City = co.City,
                Street = co.Street,
                HouseNumber = co.HouseNumber,
                ApartmentNumber = co.ApartmentNumber,
                //PersonContacts = co.PersonContacts?.Select(pc => PersonContactDTO.CreateFromDomain(pc)).ToList()
            };
        }

        public Contact Transform(ContactDTO dto)
        {
            return new Contact()
            {
                Id = dto.ContactId,
                Phone = dto.Phone,
                Mail = dto.Mail,
                City = dto.City,
                Street = dto.Street,
                HouseNumber = dto.HouseNumber,
                ApartmentNumber = dto.ApartmentNumber,
                //PersonContacts = dto.PersonContacts?.Select(pc => Transform() )

            };
        }
    }
}
