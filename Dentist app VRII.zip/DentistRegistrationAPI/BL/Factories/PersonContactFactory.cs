﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IPersonContactFactory
    {
        PersonContactDTO Transform(PersonContact a);
        PersonContact Transform(PersonContactDTO dto);
    }
    public class PersonContactFactory : IPersonContactFactory
    {
        public PersonContactDTO Transform(PersonContact pc)
        {
            return new PersonContactDTO()
            {
                PersonContactId = pc.Id,
                StartDate = pc.StartDate,
                EndDate = pc.EndDate,
                //Person = PersonDTO.CreateFromDomain(pc.Person),
                //Contact = ContactDTO.CreateFromDomain(pc.Contact)
            };
        }

        public PersonContact Transform(PersonContactDTO dto)
        {
            return new PersonContact()
            {
                Id = dto.PersonContactId,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                //PersonId = dto.Person.PersonId,
                //ContactId = dto.Contact.ContactId
            };
        }
    }
}
