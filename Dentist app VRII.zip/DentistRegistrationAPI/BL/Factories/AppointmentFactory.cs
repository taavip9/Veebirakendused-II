﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IAppointmentFactory
    {
        AppointmentDTO Transform(Appointment a);
        Appointment Transform(AppointmentDTO dto);
    }

    public class AppointmentFactory :IAppointmentFactory
    {
        public AppointmentDTO Transform(Appointment a)
        {
            return new AppointmentDTO()
            {
                AppoinmentId = a.Id,
                AppDate = a.AppDate,
                Length = a.Length,
                AppointmentType = AppointmentTypeDTO.CreateFromDomain(a.AppointmentType),
                DoctorPerson = PersonDTO.CreateFromDomain(a.Person),
                PatientPerson = PersonDTO.CreateFromDomain(a.Person),
            };
        }

        public Appointment Transform(AppointmentDTO dto)
        {
            return new Appointment()
            {
                Id = dto.AppoinmentId,
                AppDate = dto.AppDate,
                AppointmentTypeId = dto.AppointmentType.AppointmentTypeId,
                PatientPersonId = dto.PatientPerson.PersonId,
                DoctorPersonId = dto.DoctorPerson.PersonId,
                Length = dto.Length
            };
            
        }
    }
}
