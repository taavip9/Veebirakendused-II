﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IClinicFactory
    {
        ClinicDTO Transform(Clinic c);
        Clinic Transform(ClinicDTO dto);
    }
    public class ClinicFactory : IClinicFactory
    {
        public ClinicDTO Transform(Clinic c)
        {
            return new ClinicDTO()
            {
                ClinicId = c.Id,
                Address = c.Address,
                ContactMail = c.ContactMail,
                ContactPhone = c.ContactPhone,
                Description = c.Description,
                PersonClinics = c.PersonClinics?.Select(pc => PersonClinicDTO.CreateFromDomain(pc)).ToList(),
                WorkingHours = c.WorkingHours?.Select(wh => WorkingHoursDTO.CreateFromDomain(wh)).ToList()
            };

        }

        public Clinic Transform(ClinicDTO clinicDTO)
        {
            return new Clinic()
            {
                Id = clinicDTO.ClinicId,
                Address = clinicDTO.Address,
                ContactMail = clinicDTO.ContactMail,
                ContactPhone = clinicDTO.ContactPhone,
                Description = clinicDTO.Description
            };
        }

    }
}
