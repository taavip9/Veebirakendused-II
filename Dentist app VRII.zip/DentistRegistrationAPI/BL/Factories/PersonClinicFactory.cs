﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IPersonClinicFactory
    {
        PersonClinicDTO Transform(PersonClinic a);
        PersonClinic Transform(PersonClinicDTO dto);
    }
    public class PersonClinicFactory : IPersonClinicFactory
    {
        public PersonClinicDTO Transform(PersonClinic pc) => new PersonClinicDTO()
        {
            StartDate = pc.StartDate,
            EndDate = pc.EndDate,
            Procedure = ProcedureDTO.CreateFromDomain(pc.Procedure),
            Person = PersonDTO.CreateFromDomain(pc.Person),
            Clinic = ClinicDTO.CreateFromDomain(pc.Clinic),
            Appointments = pc.Appointments?.Select(ap => AppointmentDTO.CreateFromDomain(ap)).ToList()

        };

        public PersonClinic Transform(PersonClinicDTO dto)
        {
            return new PersonClinic()
            {
                Id = dto.PersonClinicId,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                ProcedureId = dto.Procedure.ProcedureId,
                ClinicId = dto.Clinic.ClinicId
            };
        }
    }
}
