﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IRoleFactory
    {
        RoleDTO Transform(Role a);
        Role Transform(RoleDTO dto);
    }
    public class RoleFactory : IRoleFactory
    {
        public RoleDTO Transform(Role ro)
        {
            return new RoleDTO()
            {
                RoleId = ro.Id,
                Name = ro.Name,
                Description = ro.Description,
                PersonRoles = ro.PersonRoles.Select(pr => PersonRoleDTO.CreateFromDomain(pr)).ToList()
            };
        }

        public Role Transform(RoleDTO dto)
        {
            return new Role()
            {
                Id = dto.RoleId,
                Name = dto.Name,
                Description = dto.Description,
            };
        }
    }
}
