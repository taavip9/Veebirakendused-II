﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IPersonFactory
    {
        PersonDTO Transform(Person p);
        Person Transform(PersonDTO dto);
    }

    public class PersonFactory : IPersonFactory
    {
        public PersonDTO Transform(Person p)
        {
            return new PersonDTO()
            {
                PersonId = p.Id,
                FirstName = p.Firstname,
                LastName = p.Lastname,
                IdentityCode = p.IdentityCode,
                PersonAppointments = p.Appointments?.Select(a => AppointmentDTO.CreateFromDomain(a)).ToList(),
                PersonRoles = p.PersonRoles?.Select(pr => PersonRoleDTO.CreateFromDomain(pr)).ToList(),
                PersonClinic = p.PersonClinics.Select(pc => PersonClinicDTO.CreateFromDomain(pc)).ToList(),
                PersonContact = p.PersonContacts.Select(pc => PersonContactDTO.CreateFromDomain(pc)).ToList()
            };
        }

        public Person Transform(PersonDTO personDTO)
        {
            return new Person()
            {
                Id = personDTO.PersonId,
                IdentityCode = personDTO.IdentityCode,
                Firstname = personDTO.FirstName,
                Lastname = personDTO.LastName
            };
        }
    }
}
