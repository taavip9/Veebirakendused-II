﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IAppointmentTypeFactory
    {
        AppointmentTypeDTO Transform(AppointmentType a);
        AppointmentType Transform(AppointmentTypeDTO dto);
    }
    public class AppointmentTypeFactory : IAppointmentTypeFactory
    {
        public AppointmentTypeDTO Transform(AppointmentType a)
        {
            return new AppointmentTypeDTO()
            {
                AppointmentTypeId = a.Id,
                Name = a.Name
            };
        }

        public AppointmentType Transform(AppointmentTypeDTO dto)
        {
            return new AppointmentType()
            {
                Id = dto.AppointmentTypeId,
                Name = dto.Name
            };
        }
    }
}
