﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;
using Domain;

namespace BL.Factories
{
    public interface IPersonRoleFactory
    {
        PersonRoleDTO Transform(PersonRole a);
        PersonRole Transform(PersonRoleDTO dto);
    }
    public class PersonRoleFactory : IPersonRoleFactory
    {
        public PersonRoleDTO Transform(PersonRole pr)
        {
            return new PersonRoleDTO()
            {
                StartDate = pr.StartDate,
                EndDate = pr.EndDate,
                Person = PersonDTO.CreateFromDomain(pr.Person),
                Role = RoleDTO.CreateFromDomain(pr.Role),
            };
        }

        public PersonRole Transform(PersonRoleDTO dto)
        {
            return new PersonRole()
            {
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                PersonId = dto.Person.PersonId,
                RoleId = dto.Role.RoleId
            };
        }
    }
}
