﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IAppointmentService
    {
        List<AppointmentDTO> GetAllAppointments();

        AppointmentDTO GetAppointmentById(int appointmentId);

        List<AppointmentDTO> GetAppointmentByCustomerId(int customerPersonId);

        AppointmentDTO AddNewAppointment(AppointmentDTO newAppointment);

        void UpdateAppointment(int appointmentId, AppointmentDTO appointmentNewData);
    }
}