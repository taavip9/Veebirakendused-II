﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IContactService
    {
        List<ContactDTO> GetAllContacts();

        ContactDTO GetContactById(int personId);

        ContactDTO FindContactByPersonId(int personId);

        ContactDTO AddNewContact(ContactDTO newPerson);

        void UpdateContact(int contactId, ContactDTO contactNewData);

    }
}