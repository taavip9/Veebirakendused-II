﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IPersonClinicService
    {
        List<PersonClinicDTO> GetAllPersonClinics();

        PersonClinicDTO GetPersonClinicById(int personClinicId);

        PersonClinicDTO AddNewPersonClinic(PersonClinicDTO newPersonClinic);

        void UpdatePersonClinic(int personClinicId, PersonClinicDTO personClinicNewData);
    }
}