﻿using System;
using System.Collections.Generic;
using System.Text;
using BL.DTO;

namespace BL
{
    interface IAppointmentTypeService
    {
        List<AppointmentTypeDTO> GetAllAppointmentTypes();

        AppointmentTypeDTO GetAppointmentTypeById(int appointmentTypeId);

        AppointmentTypeDTO AddNewAppointmentType(AppointmentTypeDTO newAppointmentType);

        void UpdateAppointmentType(int appointmentTypeId, AppointmentTypeDTO appointmentTypeNewData);
    }
}
