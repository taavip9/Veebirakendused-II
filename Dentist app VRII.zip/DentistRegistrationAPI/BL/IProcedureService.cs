﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IProcedureService
    {
        List<ProcedureDTO> GetAllProcedures();

        ProcedureDTO GetProcedureById(int procedureId);

        ProcedureDTO AddNewProcedure(ProcedureDTO newProcedure);

        void UpdateProcedure(int personId, ProcedureDTO procedureNewData);

    }
}