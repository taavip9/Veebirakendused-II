﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IClinicService
    {
        List<ClinicDTO> GetAllClinics();

        ClinicDTO GetClinicById(int clinicId);

        ClinicDTO AddNewClinic(ClinicDTO newClinic);

        void UpdateClinic(int clinicId, ClinicDTO clinicNewData);
    }
}