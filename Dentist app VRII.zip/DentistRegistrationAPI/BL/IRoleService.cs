﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IRoleService
    {
        List<RoleDTO> GetAllRoles();

        RoleDTO GetRoleById(int roleId);

        RoleDTO AddNewRole(RoleDTO newRole);

        void UpdateRole(int roleId, RoleDTO roleNewData);

    }
}