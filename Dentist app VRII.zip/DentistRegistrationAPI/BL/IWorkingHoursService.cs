﻿using System.Collections.Generic;
using BL.DTO;

namespace BL
{
    public interface IWorkingHoursService
    {
        List<WorkingHoursDTO> GetAllWorkingHours();

        WorkingHoursDTO GetWorkingHoursById(int workingHoursId);

        WorkingHoursDTO AddNewWorkingHours(WorkingHoursDTO newWorkingHours);

        void UpdateWorkingHours(int workingHoursId, WorkingHoursDTO workingHoursNewData);
    }
}