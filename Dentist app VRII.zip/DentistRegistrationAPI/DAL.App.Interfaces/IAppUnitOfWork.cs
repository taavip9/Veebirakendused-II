﻿using System;
using System.Collections.Generic;
using System.Text;
using DAL.App.Interfaces.Repositories;
using DAL.Interfaces;

namespace DAL.App.Interfaces
{
    public interface IAppUnitOfWork : IUnitOfWork
    {
        IPersonRepository Persons { get; }

        IClinicRepository Clinics { get; }

        IAppointmentRepository Appointments { get; }

        IContactRepository Contacts { get; }

        IAppointmentTypeRepository AppointmentTypes { get; }

        IPersonClinicRepository PersonClinics { get; }

        IPersonContactRepository PersonContacts { get; }

        IPersonRoleRepository PersonRoles { get; }

        IProcedureRepository Procedures { get; }
        
        IRoleRepository Roles { get; }

        IWorkingHoursRepository WorkingHours { get; }

    }
}
