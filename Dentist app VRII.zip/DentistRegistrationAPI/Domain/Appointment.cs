﻿using System;

namespace Domain

{
    public class Appointment
    {
        public int Id { get; set; }

        public DateTime AppDate { get; set; }
        public TimeSpan Length { get; set; }

        public int AppointmentTypeId { get; set; }
        public AppointmentType AppointmentType { get; set; }
        
        public int PatientPersonId { get; set; }
        public int DoctorPersonId { get; set; }
        public Person Person{ get; set; }
    
    }

}

