﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain
{
    public class WorkingHours
    {
        public int Id { get; set; }
        public DateTime OpenFrom { get; set; }
        public DateTime OpenTo { get; set; }
        [MaxLength(128)]
        public string Weekday { get; set; }
        
        public int ClinicId { get; set; }
        public Clinic Clinic { get; set; }
    }
}