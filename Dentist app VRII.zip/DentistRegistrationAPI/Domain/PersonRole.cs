﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain
{
    public class PersonRole
    {
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        
        public int PersonId { get; set; }
        public Person Person { get; set; }

        public int RoleId { get; set; }
        public Role Role { get; set; }
    }
}