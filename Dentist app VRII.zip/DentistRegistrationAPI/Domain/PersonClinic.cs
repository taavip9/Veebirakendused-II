﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    public class PersonClinic
    {
        public int Id { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public int ProcedureId { get; set; }
        public Procedure Procedure { get; set; }

        public int PersonId { get; set; }
        public Person Person { get; set; }

        public int? ClinicId { get; set; }
        public Clinic Clinic { get; set; }

        public List<Appointment> Appointments { get; set; } = new List<Appointment>();
    }
}
