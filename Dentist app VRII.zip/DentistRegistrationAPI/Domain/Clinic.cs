﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain
{
    public class Clinic
    {
        public int Id { get; set; }

        [MaxLength(256)]
        public string Address { get; set; }

        [MaxLength(64)]
        public string ContactPhone { get; set; }

        [MaxLength(128)]
        public string ContactMail { get; set; }

        [MaxLength(256)]
        public string Description { get; set; }

        public List<PersonClinic> PersonClinics { get; set; } = new List<PersonClinic>();

        public List<WorkingHours> WorkingHours { get; set; } = new List<WorkingHours>();

    }
}
