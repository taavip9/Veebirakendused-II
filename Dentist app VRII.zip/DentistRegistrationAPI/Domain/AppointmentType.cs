﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain
{
    public class AppointmentType
    {
        public int Id { get; set; }

        [MaxLength(128)]
        public string Name { get; set; }
        
    }
}
