﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain
{

public class Contact
    {
        public int Id { get; set; }

        [MaxLength(128)]
        public string Phone { get; set; }
        [MaxLength(128)]
        public string Mail { get; set; }
        [MaxLength(64)]
        public string City { get; set; }
        [MaxLength(64)]
        public string Street { get; set; }
        [MaxLength(64)]
        public string HouseNumber { get; set; }
        [MaxLength(64)]
        public string ApartmentNumber { get; set; }

        public List<PersonContact> PersonContacts { get; set; } = new List<PersonContact>();
    }
}
