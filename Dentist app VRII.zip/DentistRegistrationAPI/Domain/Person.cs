﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain
{
    public class Person
    {
        public int Id { get; set; }

        [MaxLength(64)] public string Firstname { get; set; }

        [MaxLength(64)] public string Lastname { get; set; }
        
        [MaxLength(128)]
        public string IdentityCode { get; set; }

        public List<PersonClinic> PersonClinics { get; set; } = new List<PersonClinic>();
        public List<Appointment> Appointments { get; set; } = new List<Appointment>();
        public List<PersonContact> PersonContacts { get; set; } = new List<PersonContact>();
        public List<PersonRole> PersonRoles { get; set; } = new List<PersonRole>();
    }
}
