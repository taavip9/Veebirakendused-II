﻿using System;

namespace BLayer
{
    public class Class1
    {
    }
}
