﻿namespace DAL.Interfaces
{
    public interface IDataContext
    {
        
    }
}