﻿using System;
using System.Threading.Tasks;
using DAL.App.Interfaces;
using DAL.App.Interfaces.Helpers;
using DAL.App.Interfaces.Repositories;
using DAL.Interfaces;
using DAL.Interfaces.Repositories;

namespace DAL.App.EF
{
    public class AppEFUnitOfWork : IAppUnitOfWork
    {
        private readonly ApplicationDbContext _applicationDbContext;
        private readonly IRepositoryProvider _repositoryProvider;

        public AppEFUnitOfWork(IDataContext dataContext, IRepositoryProvider repositoryProvider)
        {
            _repositoryProvider = repositoryProvider;
            _applicationDbContext = dataContext as ApplicationDbContext;
            if (_applicationDbContext == null)
            {
                throw new NullReferenceException("No EF dbcontext found in UOW");
            }
        }
        public IPersonRepository Persons => GetCustomRepository<IPersonRepository>();
        public IClinicRepository Clinics => GetCustomRepository<IClinicRepository>();
        public IAppointmentRepository Appointments => GetCustomRepository<IAppointmentRepository>();
        public IAppointmentTypeRepository AppointmentTypes => GetCustomRepository<IAppointmentTypeRepository>();
        public IPersonClinicRepository PersonClinics => GetCustomRepository<IPersonClinicRepository>();
        public IPersonContactRepository PersonContacts => GetCustomRepository<IPersonContactRepository>();
        public IPersonRoleRepository PersonRoles => GetCustomRepository<IPersonRoleRepository>();
        public IProcedureRepository Procedures => GetCustomRepository<IProcedureRepository>();
        public IRoleRepository Roles => GetCustomRepository<IRoleRepository>();
        public IWorkingHoursRepository WorkingHours => GetCustomRepository<IWorkingHoursRepository>();
        public IContactRepository Contacts => GetCustomRepository<IContactRepository>();

        public void SaveChanges()
        {
            _applicationDbContext.SaveChanges();
        }

        public async Task SaveChangesAsync()
        {
            await _applicationDbContext.SaveChangesAsync();
        }

        public IRepository<TEntity> GetEntityRepository<TEntity>() where TEntity : class
        {
            return _repositoryProvider.GetEntityRepository<TEntity>();
        }

        public TRepositoryInterface GetCustomRepository<TRepositoryInterface>() where TRepositoryInterface : class
        {
            return _repositoryProvider.GetCustomRepository<TRepositoryInterface>();
        }
    }
}
