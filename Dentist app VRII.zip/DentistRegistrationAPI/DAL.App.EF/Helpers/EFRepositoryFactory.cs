﻿using System;
using System.Collections.Generic;
using System.Text;
using DAL.App.EF.Repositories;
using DAL.App.Interfaces.Helpers;
using DAL.App.Interfaces.Repositories;
using DAL.EF.Repositories;
using DAL.Interfaces;
using DAL.Interfaces.Repositories;

namespace DAL.App.EF.Helpers
{
    public class EFRepositoryFactory : IRepositoryFactory
    {
        private readonly Dictionary<Type, Func<IDataContext, object>> _customRepositoryFactories
            = GetCustomRepoFactories();

        private static Dictionary<Type, Func<IDataContext, object>> GetCustomRepoFactories()
        {
            return new Dictionary<Type, Func<IDataContext, object>>()
            {
                {typeof(IPersonRepository), (dataContext) => new EFPersonRepository(dataContext as ApplicationDbContext) },
                {typeof(IClinicRepository), (dataContext) => new EFClinicRepository(dataContext as ApplicationDbContext) },
                {typeof(IAppointmentRepository), (dataContext) => new EFAppointmentRepository(dataContext as ApplicationDbContext) },
                {typeof(IContactRepository), (dataContext) => new EFContactRepository(dataContext as ApplicationDbContext) },
                {typeof(IAppointmentTypeRepository), (dataContext) => new EFAppointmentTypeRepository(dataContext as ApplicationDbContext) },
                {typeof(IPersonClinicRepository), (dataContext) => new EFPersonClinicRepository(dataContext as ApplicationDbContext) },
                {typeof(IPersonContactRepository), (dataContext) => new EFPersonContactRepository(dataContext as ApplicationDbContext) },
                {typeof(IPersonRoleRepository), (dataContext) => new EFPersonRoleRepository(dataContext as ApplicationDbContext) },
                {typeof(IProcedureRepository), (dataContext) => new EFProcedureRepository(dataContext as ApplicationDbContext) },
                {typeof(IRoleRepository), (dataContext) => new EFRoleRepository(dataContext as ApplicationDbContext) },
                {typeof(IWorkingHoursRepository), (dataContext) => new EFWorkingHoursRepository(dataContext as ApplicationDbContext) },
            };
        }

        public Func<IDataContext, object> GetCustomRepositoryFactory<TRepoInterface>() where TRepoInterface : class
        {
            _customRepositoryFactories.TryGetValue(
                typeof(TRepoInterface),
                out Func<IDataContext, object> factory
            );
            return factory;
        }

        public Func<IDataContext, object> GetStandardRepositoryFactory<TEntity>() where TEntity : class
        {

            return (dataContext) => new EFRepository<TEntity>(dataContext as ApplicationDbContext);
        }
    }
}
