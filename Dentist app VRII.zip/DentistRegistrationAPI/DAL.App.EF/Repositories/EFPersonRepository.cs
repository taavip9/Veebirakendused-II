﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.App.EF.Helpers;
using DAL.App.Interfaces.Repositories;
using DAL.EF.Repositories;
using Domain;
using Microsoft.EntityFrameworkCore;

namespace DAL.App.EF.Repositories
{
    class EFPersonRepository : EFRepository<Person>, IPersonRepository
    {
        public EFPersonRepository(DbContext dataContext) : base(dataContext)
        {
        }
        public bool Exists(int id)
        {
            return RepositoryDbSet.Any(e => e.Id == id);
        }

        public List<Person> findWithMatchingContacts(int personId)
        {
            //return RepositoryDbSet.Include(x => x.PersonContacts).Where.ToList();
            return RepositoryDbSet.Include(x => x.PersonContacts).Where(x => personId == x.Id).ToList();
        }
    }
}
