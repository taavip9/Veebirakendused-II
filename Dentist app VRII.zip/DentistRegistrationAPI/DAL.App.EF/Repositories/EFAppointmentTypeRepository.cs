﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DAL.App.Interfaces.Repositories;
using DAL.EF.Repositories;
using Domain;
using Microsoft.EntityFrameworkCore;

namespace DAL.App.EF.Repositories
{
    class EFAppointmentTypeRepository : EFRepository<AppointmentType>, IAppointmentTypeRepository
    {
        public EFAppointmentTypeRepository(DbContext dataContext) : base(dataContext)
        {
        }
    }
}
