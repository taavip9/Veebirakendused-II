﻿using System;
using System.Collections.Generic;
using System.Text;
using DAL.App.Interfaces.Repositories;
using DAL.EF.Repositories;
using Domain;
using Microsoft.EntityFrameworkCore;

namespace DAL.App.EF.Repositories
{
    class EFPersonClinicRepository : EFRepository<PersonClinic>, IPersonClinicRepository
    {
        public EFPersonClinicRepository(DbContext dataContext) : base(dataContext)
        {
        }
    }
}
