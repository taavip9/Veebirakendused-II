﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL.App.Interfaces.Repositories;
using DAL.EF.Repositories;
using Domain;
using Microsoft.EntityFrameworkCore;

namespace DAL.App.EF.Repositories
{
    class EFContactRepository: EFRepository<Contact>, IContactRepository
    {
        private IPersonContactRepository personContactRepository;
        public EFContactRepository(DbContext dataContext) : base(dataContext)
        {
            personContactRepository = new EFPersonContactRepository(RepositoryDbContext);
        }

        public Contact findContactByPersonId(int personId)
        {
            PersonContact personContact = personContactRepository.All().Find(
                delegate(PersonContact pc) { return pc.PersonId == personId; });
            int personContactId = personContact.ContactId;
            return RepositoryDbSet.Find(personContactId);
        }
    }
}
