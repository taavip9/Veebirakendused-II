﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BL;
using BL.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DAL.App.EF;
using Domain;

namespace WebApp.Controllers.api
{
    [Produces("application/json")]
    [Route("api/Clinics")]
    public class ClinicsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IClinicService _clinicService;

        public ClinicsController(IClinicService clinicService)
        {
            _clinicService = clinicService;
        }

        // GET: api/Clinics
        [HttpGet]
        public List<ClinicDTO> GetClinics()
        {
            return _clinicService.GetAllClinics();
        }

        // GET: api/Clinics/5
        [HttpGet("{id}")]
        public IActionResult GetClinic([FromRoute] int id)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var clinic = _clinicService.GetClinicById(id);
            if (clinic == null) return NotFound();
            return Ok(clinic);
        }

        // PUT: api/Clinics/5
        [HttpPut("{id}")]
        public IActionResult PutClinic([FromRoute] int id, [FromBody] Clinic clinic)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            _clinicService.UpdateClinic(id, ClinicDTO.CreateFromDomain(clinic));

            return Ok();
        }

        // POST: api/Clinics
        [HttpPost]
        public async Task<IActionResult> PostClinic([FromBody] Clinic clinic)
        {
            if (!ModelState.IsValid)  return BadRequest(ModelState);
            
            _clinicService.AddNewClinic(ClinicDTO.CreateFromDomain(clinic));

            return CreatedAtAction("GetClinic", new { id = clinic.Id }, clinic);
        }

        // DELETE: api/Clinics/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteClinic([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var clinic = await _context.Clinics.SingleOrDefaultAsync(m => m.Id == id);
            if (clinic == null)
            {
                return NotFound();
            }

            _context.Clinics.Remove(clinic);
            await _context.SaveChangesAsync();

            return Ok(clinic);
        }

        private bool ClinicExists(int id)
        {
            return _context.Clinics.Any(e => e.Id == id);
        }
    }
}