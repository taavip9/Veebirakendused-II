﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BL;
using BL.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DAL.App.EF;
using Domain;

namespace WebApp.Controllers.api
{
    [Produces("application/json")]
    [Route("api/Appointments")]
    public class AppointmentsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IAppointmentService _appointmentService;

        public AppointmentsController(IAppointmentService appointmentService)
        {
            _appointmentService = appointmentService;
        }

        // GET: api/Appointments
        [HttpGet]
        public IEnumerable<AppointmentDTO> GetAppointments()
        {
            return _appointmentService.GetAllAppointments();
        }

        // GET: api/Appointments/5
        [HttpGet("{id}")]
        public IActionResult GetAppointment([FromRoute] int id)
        {
            if (!ModelState.IsValid)  return BadRequest(ModelState);

            var appointment = _appointmentService.GetAppointmentById(id);

            return Ok(appointment);
        }

        // GET: api/Appointments/5
        [Route("byPersonId/{id}")]
        [HttpGet]
        public IEnumerable<AppointmentDTO> GetAppointmentByPersonId([FromRoute] int id)
        {

            return _appointmentService.GetAppointmentByCustomerId(id);
        }

        // PUT: api/Appointments/5
        [HttpPut("{id}")]
        public IActionResult PutAppointment([FromRoute] int id, [FromBody] Appointment appointment)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            _appointmentService.UpdateAppointment(id, AppointmentDTO.CreateFromDomain(appointment));

            return NoContent();
        }

        // POST: api/Appointments
        [HttpPost]
        public IActionResult PostAppointment([FromBody] Appointment appointment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _appointmentService.AddNewAppointment(AppointmentDTO.CreateFromDomain(appointment));



            return CreatedAtAction("GetAppointment", new { id = appointment.Id }, appointment);
        }

        // DELETE: api/Appointments/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAppointment([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var appointment = await _context.Appointments.SingleOrDefaultAsync(m => m.Id == id);
            if (appointment == null)
            {
                return NotFound();
            }

            _context.Appointments.Remove(appointment);
            await _context.SaveChangesAsync();

            return Ok(appointment);
        }

        private bool AppointmentExists(int id)
        {
            return _context.Appointments.Any(e => e.Id == id);
        }
    }
}