﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BL;
using BL.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DAL.App.EF;
using Domain;

namespace WebApp.Controllers.api
{
    [Produces("application/json")]
    [Route("api/PersonContacts")]
    public class PersonContactsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IPersonContactService _personContactService;

        public PersonContactsController(ApplicationDbContext context, IPersonContactService personContactService)
        {
            _context = context;
            _personContactService = personContactService;
        }

        // GET: api/PersonContacts
        [HttpGet]
        public IEnumerable<PersonContactDTO> GetPersonContacts()
        {
            return _personContactService.GetAllPersonContacts();
        }

        // GET: api/PersonContacts/5
        [HttpGet("{id}")]
        public IEnumerable<PersonContactDTO> GetPersonContact([FromRoute] int id)
        {

            //var r = _personContactService.GetByPersonId(id);
            //if (r == null) return NotFound();
            return _personContactService.GetByPersonId(id);
        }

        // PUT: api/PersonContacts/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPersonContact([FromRoute] int id, [FromBody] PersonContact personContact)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != personContact.Id)
            {
                return BadRequest();
            }

            _context.Entry(personContact).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PersonContactExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PersonContacts
        [HttpPost]
        public async Task<IActionResult> PostPersonContact([FromBody] PersonContact personContact)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.PersonContacts.Add(personContact);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPersonContact", new { id = personContact.Id }, personContact);
        }

        // DELETE: api/PersonContacts/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePersonContact([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var personContact = await _context.PersonContacts.SingleOrDefaultAsync(m => m.Id == id);
            if (personContact == null)
            {
                return NotFound();
            }

            _context.PersonContacts.Remove(personContact);
            await _context.SaveChangesAsync();

            return Ok(personContact);
        }

        private bool PersonContactExists(int id)
        {
            return _context.PersonContacts.Any(e => e.Id == id);
        }
    }
}