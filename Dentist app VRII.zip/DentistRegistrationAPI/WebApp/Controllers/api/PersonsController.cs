﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DAL.App.EF;
using Domain;
using BL;
using BL.DTO;

namespace WebApp.Controllers.api
{
    [Produces("application/json")]
    [Route("api/Persons")]
    public class PersonsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IPersonService _personService;

        public PersonsController(IPersonService personService)
        {
            _personService = personService;

        }

        // GET: api/Persons
        [HttpGet]
        public IEnumerable<PersonDTO> GetPeople()
        {
            return _personService.GetAllPersons();
        }

        // GET: api/Persons/5
        [HttpGet("{id}")]
        public IActionResult GetPerson([FromRoute] int id)
        {
            var r = _personService.GetPersonWithContactsById(id);
            if (r == null) return NotFound();
            return Ok(r);
        }

        // POST: api/Persons
        [HttpPost]
        public IActionResult PostPerson([FromBody] Person person)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            
            _personService.AddNewPerson(PersonDTO.CreateFromDomain(person));

            return CreatedAtAction("GetPerson", new { id = person.Id }, person);
        }

        // PUT: api/Persons/5
        [HttpPut("{id}")]
        public IActionResult PutPerson([FromRoute] int id, [FromBody] Person person)
        {
            _personService.UpdatePerson(id, PersonDTO.CreateFromDomain(person));

            return Ok();
        }

        // DELETE: api/Persons/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePerson([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var person = await _context.People.SingleOrDefaultAsync(m => m.Id == id);
            if (person == null)
            {
                return NotFound();
            }

            _context.People.Remove(person);
            await _context.SaveChangesAsync();

            return Ok(person);
        }

        private bool PersonExists(int id)
        {
            return _context.People.Any(e => e.Id == id);
        }
    }
}