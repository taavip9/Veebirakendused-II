using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApp.Controllers;
using WebApp.Controllers.api;

namespace Microsoft.AspNetCore.Mvc
{
    public static class UrlHelperExtensions
    {

    }
}
