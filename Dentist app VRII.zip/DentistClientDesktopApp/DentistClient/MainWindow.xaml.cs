﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DentistClient.Models;
using DentistClient.ViewModels;
using DentistClient.Views;

namespace DentistClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MainWindowVM _vm;
        public MainWindow()
        {
            InitializeComponent();
            _vm = new MainWindowVM();
            this.DataContext = _vm;
        }

        private async void LogInClicked(object sender, RoutedEventArgs e)
        {
            _vm.RequestLogIn(new Models.ApplicationUser { Email = UsernameBox.Text, Password = PasswordBox.Password});
            _vm.PropertyChanged += VmOnPropertyChanged;

        }

        private void VmOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (_vm.isLogInSuccessful)
            {
                String userRole = _vm.roleFromToken;
                Window newWindow = new Window();

                if (userRole == "Admin")
                    newWindow = new AdminMainWindow();
                else if (userRole == "Customer")
                    newWindow = new CustomerMainWindow(_vm._personFromAppUser);
                else if (userRole == "Doctor")
                    newWindow = new DoctorMainWindow();
                else if (userRole == null)
                    newWindow = new MainWindow();

                newWindow.Show();
                Close();
            }
        }

        private void RegisterAccountClicked(object sender, RoutedEventArgs e)
        {
            var RegisterUserWindow = new GuestRegisterNewUserWindow();
            RegisterUserWindow.Show();
        }
    }
}
