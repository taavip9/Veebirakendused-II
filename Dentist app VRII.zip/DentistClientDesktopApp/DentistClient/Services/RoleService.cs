﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DentistClient.Services
{
    class RoleService : BaseService
    {
        public RoleService(string uri) : base(uri)
        {
        }
    }
}
