﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;

namespace DentistClient.Services
{
    class AppointmentService : BaseService
    {
        public AppointmentService() : base(Config.AppointmentServiceUrl)
        {
        }

        public async Task<List<Appointment>> GetAppointmentsByPatientId(int id)
        {

            return await Get<List<Appointment>>(Config.AppointmentServiceUrl + "/byPersonId/"+ id);
        }
    }
}
