﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;
using Newtonsoft.Json.Linq;

namespace DentistClient.Services
{
    class SecurityTokenService : BaseService
    {
        public SecurityTokenService() : base(Config.TokenUrl)
        {
        }

        public async Task<ApplicationUser> RequestLogIn(ApplicationUser user)
        {
            var response = await _client.PostAsJsonAsync(Config.TokenUrl, user);
            if (response.IsSuccessStatusCode)
                querySuccessful = true;
            var al = JObject.Parse(response.Content.ReadAsStringAsync().Result);
            var result = al["token"].ToString();
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            var claims = tokenHandler.ReadJwtToken(result).Claims;
            roleFromToken = claims.ElementAt(4).Value;
            return await response.Content.ReadAsAsync<ApplicationUser>();
        }
    }
}
