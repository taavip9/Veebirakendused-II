﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;
using Newtonsoft.Json.Linq;

namespace DentistClient.Services
{
    class ApplicationUserService : BaseService
    {
        public ApplicationUserService() : base(Config.AccountUrl)
        {

        }


        public async Task<String> GetUserByMail(String mail)
        {
            ApplicationUser user = await Get<ApplicationUser>(Config.AccountUrl + "/" + mail);
            var response = await _client.GetAsync(Config.AccountUrl + "/" + mail);
            if (response.IsSuccessStatusCode)
                querySuccessful = true;
            var al = JObject.Parse(response.Content.ReadAsStringAsync().Result);
            var result = al["personId"].ToString();
            return result;
        }

        public async Task<ApplicationUser> RequestLogIn(ApplicationUser p)
        {
            return await Post("/Login", p);
        }
    }
}
