﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;

namespace DentistClient.Services
{
    class ProcedureService : BaseService
    {
        public ProcedureService(string uri) : base(uri)
        {
        }

        public async Task<List<Procedure>> GetAllProcedures()
        {
            return await Get<List<Procedure>>("");
        }

        public async Task<Procedure> AddNewProcedure(Procedure p)
        {
            return await Post("", p);
        }
    }
}
