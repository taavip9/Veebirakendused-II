﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using DentistClient.Models;

namespace DentistClient.Services
{
    class PersonService : BaseService
    {
        public PersonService() : base(Config.PersonServiceUrl)
        {
        }
        public async Task<List<Person>> GetPersonById(int id)
        {

            return await Get <List<Person>> (Config.PersonServiceUrl+"/"+id);
        }

        public async Task<List<Person>> GetAllPersons()
        {
            return await Get<List<Person>>("");
        }

        public async Task<Person> AddNewPerson(Person p)
        {

            return await Post("", p);
        }
    }
}
