﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace DentistClient.Services
{
    class BaseService
    {
        protected HttpClient _client;
        public Boolean querySuccessful { get; set; }
        public String roleFromToken { get; set; }

        public BaseService(string uri)
        {
            _client = new HttpClient();
            _client.BaseAddress = new Uri(uri);
        }

        public async Task<T> Get<T>(string url)
        {
            var response = await _client.GetAsync(url);
            return await response.Content.ReadAsAsync<T>();
        }

        public async Task<T> Post<T>(string url, T obj)
        {
            var response = await _client.PostAsJsonAsync(url, obj);
            
            return await response.Content.ReadAsAsync<T>();
        }
    }
}
