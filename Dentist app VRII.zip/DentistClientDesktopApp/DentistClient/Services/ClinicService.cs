﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;

namespace DentistClient.Services
{
    class ClinicService : BaseService
    {
        public ClinicService(string uri) : base(uri)
        {
        }

        public async Task<List<Clinic>> GetAllClinics()
        {
            return await Get<List<Clinic>>("");
        }

        public async Task<Clinic> AddNewClinics(Clinic c)
        {
            return await Post("", c);
        }
    }
}
