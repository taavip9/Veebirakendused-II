﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;

namespace DentistClient.Services
{
    class ApplicationUserRegisterService : BaseService
    {
        public ApplicationUserRegisterService() : base(Config.RegisterUrl)
        {

        }

        public async Task<ApplicationUser> RegisterUser(ApplicationUser user)
        {
            return await Post("", user);
        }
    }
}
