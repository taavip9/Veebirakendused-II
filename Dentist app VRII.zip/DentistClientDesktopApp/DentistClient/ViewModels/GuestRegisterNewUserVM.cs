﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;
using DentistClient.Services;

namespace DentistClient.ViewModels
{
    class GuestRegisterNewUserVM
    {
        #region  inotify example
        public event PropertyChangedEventHandler PropertyChanged;

        // This method is called by the Set accessor of each property.
        // The CallerMemberName attribute that is applied to the optional propertyName
        // parameter causes the property name of the caller to be substituted as an argument.
        private void NotifyPropertyChanged(string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        PersonService _personService = new PersonService();

        public GuestRegisterNewUserVM()
        {
            _personService = new PersonService();
            //People = new List<Person>();
        }

        public async void AddNewPerson(Person p)
        {

            await _personService.AddNewPerson(p);
        }
    }
}
