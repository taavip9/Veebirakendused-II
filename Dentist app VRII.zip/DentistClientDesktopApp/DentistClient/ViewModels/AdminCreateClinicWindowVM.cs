﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Annotations;
using DentistClient.Models;
using DentistClient.Services;

namespace DentistClient.ViewModels
{
    class AdminCreateClinicWindowVM
    {
        private List<Clinic> _clinics;
        private ClinicService _clinicService;

        public event PropertyChangedEventHandler PropertyChanged;

           private void NotifyPropertyChanged(string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public AdminCreateClinicWindowVM(List<Clinic> clinics, ClinicService clinicService)
        {
            _clinicService = clinicService;
        }

        public List<Clinic> Clinic
        {
            get { return _clinics; }
            set
            {
                _clinics = value;
                NotifyPropertyChanged("Clinic");
            }
        }

        public async void LoadData()
        {
            Clinic = await _clinicService.GetAllClinics();
        }

        public async void AddNewClinics(Clinic c)
        {
            await _clinicService.AddNewClinics(c);
            LoadData();
        }

    }
}
