﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;
using DentistClient.Services;

namespace DentistClient.ViewModels
{
    class MainWindowVM
    {
        private ApplicationUserService _applicationUserService;
        private SecurityTokenService _securityTokenService;
        private PersonService _personService;
        public Person _personFromAppUser;

        public String roleFromToken
        {
            get { return _securityTokenService.roleFromToken; }
            set
            {
                _securityTokenService.roleFromToken = value;
                NotifyPropertyChanged("isLogInSuccessful");
            }
        }

        public Person getPersonFromApplicationUser(ApplicationUser user)
        {
            return null;
        }

        public Boolean isLogInSuccessful
        {
            get { return _securityTokenService.querySuccessful; }
            set
            {
                _securityTokenService.querySuccessful = value;
                NotifyPropertyChanged("isLogInSuccessful");
            }
        }

        public MainWindowVM()
        {
            _applicationUserService = new ApplicationUserService();
            _securityTokenService = new SecurityTokenService();
            _personService = new PersonService();
            roleFromToken = _securityTokenService.roleFromToken;
            //People = new List<Person>();
        }


        public async void RequestLogIn(ApplicationUser user)
        {
            var res1 = await _securityTokenService.RequestLogIn(user);
            var personId = await _applicationUserService.GetUserByMail(user.Email);
            if (!String.IsNullOrEmpty(personId))
            {
                var person = await _personService.GetPersonById(Int32.Parse(personId));
                _personFromAppUser = person[0];
            }
            isLogInSuccessful = _securityTokenService.querySuccessful;
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName = "securityTokenService.querySuccessful")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
