﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Annotations;
using DentistClient.Models;
using DentistClient.Services;

namespace DentistClient.ViewModels
{
    class AdminCreateProcedureWindowVm : INotifyPropertyChanged
    {
        private List<Procedure> _procedures;
        private ProcedureService _procedureService;


        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public AdminCreateProcedureWindowVm(ProcedureService procedureService, List<Procedure> procedures)
        {
            _procedureService = procedureService;
        }

        public List<Procedure> Procedures
        {
            get { return _procedures; }
            set
            {
                _procedures = value;
                NotifyPropertyChanged("Procedure");
            }
        }

        public async void LoadData()
        {
            Procedures = await _procedureService.GetAllProcedures();
        }

        public async void AddNewProcedure(Procedure p)
        {
            await _procedureService.AddNewProcedure(p);
            LoadData();
            }

    }
}