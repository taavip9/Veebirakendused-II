﻿using DentistClient.Models;
using DentistClient.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Annotations;

namespace DentistClient.ViewModels
{
    class AdminManageUsersWindowVM : INotifyPropertyChanged
    {
        private List<Person> _people;

        private PersonService _personService;

        public event PropertyChangedEventHandler PropertyChanged;

        // This method is called by the Set accessor of each property.
        // The CallerMemberName attribute that is applied to the optional propertyName
        // parameter causes the property name of the caller to be substituted as an argument.
        private void NotifyPropertyChanged(string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public List<Person> People
        {
            get { return _people; }
            set
            {
                _people = value;
                NotifyPropertyChanged("People");
            }
        }

        public AdminManageUsersWindowVM()
        {
            _personService = new PersonService();
            //People = new List<Person>();
        }

        public async void LoadData()
        {
            People = await _personService.GetAllPersons();
        }

        public async void AddNewPerson(Person p)
        {

            //await _personService.AddNewPerson(p);
            //LoadData();
        }
    }
}
