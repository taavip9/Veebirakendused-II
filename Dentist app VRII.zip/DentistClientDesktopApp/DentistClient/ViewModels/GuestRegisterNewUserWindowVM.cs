﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DentistClient.Models;
using DentistClient.Services;

namespace DentistClient.ViewModels
{
    class GuestRegisterNewUserWindowVM
    {
        private ApplicationUserRegisterService _applicationUserRegisterService;

        public GuestRegisterNewUserWindowVM()
        {
            _applicationUserRegisterService = new ApplicationUserRegisterService();
        }


        public async void AddNewPerson(Person p, ApplicationUser user)
        {
            await _applicationUserRegisterService.RegisterUser(user);
        }
    }

}
