﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DentistClient.Models
{
    class ApplicationUser
    {
        public String Email { get; set; }
        public String Password { get; set; }
        public String Role { get; set; }
        public Person Person { get; set; }

        public override string ToString()
        {
            return $"{Email} {Password} {Role} {Person}";
        }
    }
}
