﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DentistClient.Models
{
    public class Person
    {
        public int PersonId { get; set; }
        public string IdentityCode { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }

        public override string ToString()
        {
            return $"{PersonId} {IdentityCode} {Firstname} {Lastname}";
        }
    }
}
