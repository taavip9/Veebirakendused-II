﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DentistClient.Models
{
    class Clinic
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public string ContactPhone { get; set; }
        public string ContactMail { get; set; }
        public string Description { get; set; }
    }
}
