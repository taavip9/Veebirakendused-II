﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DentistClient.Models
{
    class Appointment
    {
        public int Id { get; set; }
        public DateTime AppDate { get; set; }
        public TimeSpan Length { get; set; }

        public override string ToString()
        {
            return $"{Id} {AppDate} {Length} {Length + " min"}";
        }
    }
}
