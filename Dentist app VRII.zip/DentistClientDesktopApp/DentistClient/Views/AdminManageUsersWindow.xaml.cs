﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DentistClient.ViewModels;

namespace DentistClient.Views
{
    /// <summary>
    /// Interaction logic for AdminManageUsersWindow.xaml
    /// </summary>
    public partial class AdminManageUsersWindow : Window
    {
        private AdminManageUsersWindowVM _vm;
        public AdminManageUsersWindow()
        {
            InitializeComponent();
            this.Loaded += AdminManageUsersWindow_Loaded;
        }
        private void AdminManageUsersWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _vm = new AdminManageUsersWindowVM();
            _vm.LoadData();
            this.DataContext = _vm;
        }

        private void EditUserClicked(object sender, RoutedEventArgs e)
        {
            var EditUserWindow = new AdminEditUserWindow();
            EditUserWindow.Show();

        }

        private void CreateUserClicked(object sender, RoutedEventArgs e)
        {
            var EditUserWindow = new AdminEditUserWindow();
            EditUserWindow.Show();

        }

        private void DeleteUserClicked(object sender, RoutedEventArgs e)
        {

        }
    }
}
