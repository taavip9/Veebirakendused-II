﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DentistClient.Views
{
    /// <summary>
    /// Interaction logic for AdminManageClinicsWindow.xaml
    /// </summary>
    public partial class AdminManageClinicsWindow : Window
    {
        public AdminManageClinicsWindow()
        {
            InitializeComponent();
        }

        private void CreateClinicClicked(object sender, RoutedEventArgs e)
        {
            var CreateClinicWindow = new AdminCreateClinicsWindow();
            CreateClinicWindow.Show();

        }

        private void DeleteClinicClicked(object sender, RoutedEventArgs e)
        {

        }

        private void EditClinicClicked(object sender, RoutedEventArgs e)
        {
            var EditClinicWindow = new AdminCreateClinicsWindow();
            EditClinicWindow.Show();
        }
    }
}
