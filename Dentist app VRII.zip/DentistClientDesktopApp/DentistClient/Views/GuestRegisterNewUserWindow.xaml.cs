﻿using System.Windows;
using DentistClient.Models;
using DentistClient.ViewModels;

namespace DentistClient.Views
{
    /// <summary>
    /// Interaction logic for GuestRegisterNewUser.xaml
    /// </summary>
    public partial class GuestRegisterNewUserWindow : Window
    {
        private GuestRegisterNewUserWindowVM _vm;
        public GuestRegisterNewUserWindow()
        {
            InitializeComponent();
            _vm = new GuestRegisterNewUserWindowVM();
            this.DataContext = _vm;
        }

        private void SaveDataBtnClicked(object sender, RoutedEventArgs e)
        {
            var person = new Models.Person
            {
                IdentityCode = IdCodeBox.Text,
                Firstname = FirstnameBox.Text,
                Lastname = SurnameBox.Text
            };
            var user = new Models.ApplicationUser()
            {
                Email = EmailBox.Text,
                Password = PasswordBox.Password,
                Role = "Customer",
                Person =
                new Person {
                    IdentityCode = IdCodeBox.Text,
                    Firstname = FirstnameBox.Text,
                    Lastname = SurnameBox.Text
                }
            };
            _vm.AddNewPerson(person, user);
            Close();
            
        }
    }
}
