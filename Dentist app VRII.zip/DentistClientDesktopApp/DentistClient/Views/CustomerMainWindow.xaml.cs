﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DentistClient.Models;
using DentistClient.ViewModels;

namespace DentistClient.Views
{
    /// <summary>
    /// Interaction logic for CustomerMainWindow.xaml
    /// </summary>
    public partial class CustomerMainWindow : Window
    {
        private CustomerMainWindowVM _vm;

        private Person _personInView;
        public CustomerMainWindow(Person person)
        {
            InitializeComponent();
            this.Loaded += CustomerMainWindow_Loaded;
            _personInView = person;
            LoadFields(person);
        }


        private void CustomerMainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _vm = new CustomerMainWindowVM();
            _vm.LoadComponents(_personInView.PersonId);
            this.DataContext = _vm;
        }

        private void LoadFields(Person person)
        {
            FirstnameBox.Text = person.Firstname;
            SurnameBox.Text = person.Lastname;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void PreviousAppointmentsClick(object sender, RoutedEventArgs e)
        {


        }

        private void NewRegistrationClick(object sender, RoutedEventArgs e)
        {
            RegisterVisitWindow registerVisitWindow = new RegisterVisitWindow();
            registerVisitWindow.Show();
        }

        private void EditAppointmentClick(object sender, RoutedEventArgs e)
        {
            ViewAppointmentWindow viewAppointmentWindow = new ViewAppointmentWindow();
            viewAppointmentWindow.Show();
        }

        private void LogOutClicked(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            Close();
        }
    }
}
