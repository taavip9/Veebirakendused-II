﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DentistClient.Views
{
    /// <summary>
    /// Interaction logic for AdminManageProceduresWindow.xaml
    /// </summary>
    public partial class AdminManageProceduresWindow : Window
    {
        public AdminManageProceduresWindow()
        {
            InitializeComponent();
        }

        private void EditProcedure_OnClick(object sender, RoutedEventArgs e)
        {
            var AdminCreateProcedureWindow = new AdminCreateProcedureWindow();
            AdminCreateProcedureWindow.Show();
        }

        private void CreateProcedure_OnClick(object sender, RoutedEventArgs e)
        {
            var AdminCreateProcedureWindow = new AdminCreateProcedureWindow();
            AdminCreateProcedureWindow.Show();
        }

        private void DeleteProcedure_OnClick(object sender, RoutedEventArgs e)
        {

        }
    }
}
