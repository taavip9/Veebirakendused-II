﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DentistClient.Views
{
    /// <summary>
    /// Interaction logic for AdminMainWindow.xaml
    /// </summary>
    public partial class AdminMainWindow : Window
    {
        public AdminMainWindow()
        {
            InitializeComponent();
        }

        private void ManageUsersButton_OnClick(object sender, RoutedEventArgs e)
        {
            var ManageUsersWindow = new AdminManageUsersWindow();
            ManageUsersWindow.Show();
        }

        private void ManageProceduresButton_OnClick(object sender, RoutedEventArgs e)
        {
            var ManageProceduresWindow = new AdminManageProceduresWindow();
            ManageProceduresWindow.Show();
        }

        private void ManageClinicsButton_OnClick(object sender, RoutedEventArgs e)
        {
            var ManageClinicsWindows = new AdminManageClinicsWindow();
            ManageClinicsWindows.Show();
        }

        private void LogOutClicked(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            Close();
        }
    }
}
