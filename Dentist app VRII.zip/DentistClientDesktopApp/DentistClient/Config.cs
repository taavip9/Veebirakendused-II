﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DentistClient
{
    class Config
    {
        private static string getValue(string key)
        {
            return ConfigurationManager.AppSettings[key];
        }

        public static string PersonServiceUrl
        {
            get
            {
                return getValue("PersonServiceUrl");
            }
        }

        public static string AppointmentServiceUrl
        {
            get
            {
                return getValue("AppointmentServiceUrl");
            }
        }

        public static string AppointmentTypeServiceUrl
        {
            get
            {
                return getValue("AppointmentTypeServiceUrl");
            }
        }

        public static string ClinicHourServiceUrl
        {
            get
            {
                return getValue("ClinicHourServiceUrl");
            }
        }

        public static string ClinicServiceUrl
        {
            get
            {
                return getValue("ClinicServiceUrl");
            }
        }

        public static string ProcedureServiceUrl
        {
            get
            {
                return getValue("ProcedureServiceUrl");
            }
        }

        public static string ContactServiceUrl
        {
            get
            {
                return getValue("ContactServiceUrl");
            }
        }

        public static string RoleServiceUrl
        {
            get
            {
                return getValue("RoleServiceUrl");
            }
        }

        public static string AccountUrl
        {
            get
            {
                return getValue("AccountUrl");
            }
        }

        public static string TokenUrl
        {
            get
            {
                return getValue("TokenUrl");
            }
        }

        public static string RegisterUrl
        {
            get
            {
                return getValue("RegisterUrl");
            }
        }
    }
}
